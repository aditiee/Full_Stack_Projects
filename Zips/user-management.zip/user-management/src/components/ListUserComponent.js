import React,{ useState, useEffect} from 'react'
import { Link } from 'react-router-dom'
import UserService from '../services/UserService'
import PopUpComponent from './PopUpComponent'

const ListUserComponent = () => {

    const [users, setUsers] = useState([])
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
       getAllUsers();
    }, [])

    const getAllUsers = () => {
        setLoading(true);
        UserService.getAllUsers()
          .then((response) => {
            setUsers(response.data);
            setLoading(false);
          })
          .catch((error) => {
            setError(error);
            setLoading(false);
          });
      };

      if (loading) {
        return <p>Loading...</p>;
      }
     
      if (error) {
        return <p>Error fetching users: {error.message}</p>;
      }
     
      if (users.length === 0) {
        return ( <div className='container'>
        <h2 className='text-center'>List of User</h2>
        <Link to = "/add-user" className="btn btn-primary mb-2">Add User</Link>
        <p>No users available</p> </div>);
      }
    // const getAllUsers = () => {
    //     UserService.getAllUsers().then((response) => {
    //         setUsers(response.data)
    //         console.log(response);
    //     }).catch (error => {
    //         console.log(error);
    //     })
    // }

    const handleDeleteUser = (userId) => {
        UserService.deleteUser(userId)
          .then((response) => {
            getAllUsers();
            console.log(response);
          })
          .catch((error) => {
            console.log(error);
          });
      };

  return (
    <div className='container'>
        <h2 className='text-center'>List of User</h2>
        <Link to = "/add-user" className="btn btn-primary mb-2">Add User</Link>
        <table className='table table-bordered table-striped'>
            <thead>
                
                <th>User Id</th>
                <th>User First Name</th>
                <th>User Last Name</th>
                <th>Email ID</th>
                <th>Date of birth</th>
                <th>Actions</th>
            </thead>    
                <tbody>     
                    {
                        users.map(
                            user =>
                            <tr key={user.id}>
                                <td>{user.id}</td>
                                <td>{user.firstName}</td>
                                <td>{user.lastName}</td>
                                <td>{user.email}</td>
                                <td>{user.contactNo}</td>
                                <td>
                                    <Link className='btn btn-info' to={`/edit-user/${user.id}`}>Update</Link>
                                    <PopUpComponent userId={user.id} onDeleteUser={handleDeleteUser}></PopUpComponent>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
        </table>
      
    </div>
  )
}

export default ListUserComponent
