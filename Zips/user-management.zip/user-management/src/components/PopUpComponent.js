import React, { useState } from 'react';

const PopUpComponent  = ({ userId, onDeleteUser }) => {

      const [isPopupOpen, setPopupOpen] = useState(false);
     
      const openPopup = () => setPopupOpen(true);
      const closePopup = () => setPopupOpen(false);
     
      const handleDelete = () => {
        onDeleteUser(userId);
        closePopup();
      };
     
      return (
        <div style = {{marginLeft:"10px", display:"inline-block"}}>
          <button className='btn btn-danger' onClick={openPopup} >
            Delete
          </button>
     
          {isPopupOpen && (
            <>
            <div className="backdrop"></div>
            <div className="popup">
              <p>Are you sure you want to delete this user?</p>
              <button onClick={handleDelete} className="btn btn-danger">
                Yes, Delete
              </button>
              <button onClick={closePopup} className="btn btn-secondary">
                Cancel
              </button>
            </div>
            </>
          )}
        </div>
      );
    };

    export default PopUpComponent
