import axios from "axios";

const USER_BEST_REST_API_URL = 'http://localhost:8080/UserProject';
const NEW_USER_BEST_REST_API_URL = 'http://localhost:8080/UserProject/adduser';
const DELETE_USER_BEST_REST_API_URL = 'http://localhost:8080/UserProject/delete';
const UPDATE_USER_BEST_REST_API_URL = 'http://localhost:8080/UserProject/update';

class UserService {
    getAllUsers(){
        return axios.get(USER_BEST_REST_API_URL + '/list')
    }

    createUser(user){
        return axios.post( NEW_USER_BEST_REST_API_URL, user)
    }

    getUserId(userId){
        return axios.get(USER_BEST_REST_API_URL +  '/' + userId)
    }

    updateUser(userId, user){
        return axios.put(UPDATE_USER_BEST_REST_API_URL +  '/' +userId, user)
    }

    deleteUser(userId){
        return axios.delete(DELETE_USER_BEST_REST_API_URL +  '/' +userId)
    }
}

export default new UserService();